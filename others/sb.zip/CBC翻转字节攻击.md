## CBC翻转字节攻击
@(安全)
### CBC模式
![Alt text](./1565873423512.png)
加密过程：将Plaintext分成多组，每组16个字节，第一轮与IV进行异或，然后加密，再将第一组密文与第二组plantext进行异或，再进行加密
解密过程：与加密过程相反，先将密文解密，再与前一组密文异或，第一轮是先解密再与IV异或

**对于解密：**
设明文为X，密文为Y，解密函数为k
X[i] = k(Y[i]) Xor Y[i-1]
**对于第一组：**
X[1] = k(Y[1]) Xor IV

### CBC翻转攻击
如果客户知道明文X、密文Y和IV，并可以对其进行修改，那么可以实现CBC翻转攻击，使得后台解密得到的明文可以让我们所控制。
**控制X[i]：**
令Y[i-1] = Y[i-1] Xor X[i]，那么能够使得X[i] = 0
令Y[i-1] = Y[i-1] Xor X[i] Xor A，那么能够使得X[i] = A
控制前一组密文与当前明文异或可以使得解密为0，再异或一个值，我们就可以对其进行控制
**控制X[1]：**
令IV = IV Xor X[1]，使得X[1] = 0
令IV = IV Xor X[1] Xor A，使得X[1] = A
要控制第一组，需要对IV进行修改

### 脚本测试
```
# -*- coding: utf-8 -*-
from Crypto.Cipher import AES
from binascii import b2a_hex,a2b_hex

def encrypt(iv,plaintext):
	if len(plaintext)%16 != 0:
		print("plaintext length is invalid")
		return
	if len(iv) != 16:
		print("IV length is invalid")
		return
	key = "1234567890123456"
	aes_encrypt = AES.new(key,AES.MODE_CBC,IV=iv)
	return b2a_hex(aes_encrypt.encrypt(plaintext))

def decrypt(iv,cipher):
	if len(iv) != 16:
		print("IV length is invalid")
		return
	key = "1234567890123456"
	aes_decrypt = AES.new(key,AES.MODE_CBC,IV=iv)
	return b2a_hex(aes_decrypt.decrypt(a2b_hex(cipher)))

def test():
	iv = "ABCDEFGH12345678"
	plaintext = "0123456789ABCDEFhellocbcflipping"
	cipher = encrypt(iv,plaintext)
	print(cipher)
	de_cipher = decrypt(iv,cipher)
	print(de_cipher)
	print(a2b_hex(de_cipher))
	print("\n")

	bin_cipher = bytearray(a2b_hex(cipher))
	bin_cipher[15] = bin_cipher[15] ^ ord('g') ^ ord('G')
	de_cipher = decrypt(iv,b2a_hex(bin_cipher))
	print(de_cipher)
	print(a2b_hex(de_cipher))
	print("\n")

	bin_decipher = bytearray(a2b_hex(de_cipher))
	bin_iv = bytearray(iv.encode('ascii'))
	for i in range(0,len(iv)):
		bin_iv[i] = bin_iv[i] ^ bin_decipher[i] ^ ord('X')

	de_cipher = decrypt(bytes(bin_iv),b2a_hex(bin_cipher))
	print(de_cipher)
	print(a2b_hex(de_cipher))

test()
```